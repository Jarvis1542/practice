import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class Board extends JPanel implements KeyListener{
	
	private BufferedImage blocks;
	
	private final int blockSize = 30;	
	
	private final int boardWidth = 10;
	
	private final int boardHeight = 20;
	
	private int[][] board = new int[boardHeight][boardWidth];
	
	private Shape[] shapes = new Shape[7];	// �� ���� ��ü ����
	
	private Shape currentShape;
	
	private int moveX;
	
	private Thread t1;
	
	
	public Board() {
		
		try {
			blocks = ImageIO.read(Board.class.getResource("/tiles.png")); // BoardŬ���� �ȿ� �̹����� �ּ�
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		
		// getSubimage�� �̹����� �߶� ��������
		shapes[0] = new Shape(blocks.getSubimage(0, 0, blockSize, blockSize), 
				new int[][] {{1,1,1,1}}, this); // I - ����

		shapes[1] = new Shape(blocks.getSubimage(blockSize*1, 0, blockSize, blockSize), 
				new int[][] {{1,1,0},
							 {0,1,1}}, this); // Z - ����

		shapes[2] = new Shape(blocks.getSubimage(blockSize*2, 0, blockSize, blockSize), 
				new int[][] {{0,1,1},
							 {1,1,0}}, this); // S - ����
		
		shapes[3] = new Shape(blocks.getSubimage(blockSize*3, 0, blockSize, blockSize), 
				new int[][] {{1,1,1},
							 {0,0,1}}, this); // J - ����
		
		shapes[4] = new Shape(blocks.getSubimage(blockSize*4, 0, blockSize, blockSize), 
				new int[][] {{1,1,1},
							 {1,0,0}}, this); // L - ����
		
		shapes[5] = new Shape(blocks.getSubimage(blockSize*5, 0, blockSize, blockSize), 
				new int[][] {{1,1,1},
							 {0,1,0}}, this); // T - ����
		
		shapes[6] = new Shape(blocks.getSubimage(blockSize*6, 0, blockSize, blockSize), 
				new int[][] {{1,1},
							 {1,1}}, this); // O - ����
		
		currentShape = shapes[1];
		
		t1 = new Thread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				repaint();
				update();
				
			}
		});
	}
	
	public void update() {
		currentShape.update();
	}
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		// g.drawImage(block, 0, 0, null) blocks �̹����� x, y��ǥ�� �׸���  
		// �̹����� ������ �����ϱ����� ���� �Ҳ����� ���� true, false
		
		for(int i=0; i<boardHeight; i++) {	// ��Ʈ���� ������ �׸���
			g.drawLine(0, blockSize*i, blockSize*boardWidth, blockSize*i);
		}
		
		for(int i=0; i<boardWidth; i++) {	// ��Ʈ���� ������ �׸���
			g.drawLine(i*blockSize, 0, i*blockSize, blockSize*boardHeight);
		}
		
		
		currentShape.render(g);
		
	}
	
	public int getBlockSize() {
		return blockSize;
	}

	@Override
	public void keyPressed(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
